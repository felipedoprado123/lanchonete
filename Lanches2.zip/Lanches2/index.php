<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Pedidos - Hamburgueria Videira</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
            <div class="header">
            <h1>Hamburgueria Videira</h1>
            <p>Faça seu pedido de forma rápida e fácil</p>
              <a href="historico.php" style="color: var(--primary); text-decoration: none;">Ver Histórico de Pedidos</a>
            </div>
        <div class="cardapio">
            <div class="categorias">
                
                <!-- CATEGORIA: LANCHES -->
                <div class="categoria">
                    <h2>Lanches</h2>
                    
                    <!-- X-Salada -->
                    <div class="produto" data-id="1" data-nome="X-Salada" data-preco="18.50">
                        <div class="produto-info">
                            <img src="assets/Xsalada.jpg" alt="X-Salada" class="produto-imagem">
                            <div class="produto-detalhes">
                                <span class="produto-nome">X-Salada</span>
                                <span class="produto-desc">Hambúrguer, queijo, alface e tomate</span>
                            </div>
                        </div>
                        <span class="produto-preco">R$ 18,50</span>
                        <div class="produto-controles">
                            <button class="btn-quantidade" onclick="diminuirQuantidade(1)">-</button>
                            <span class="quantidade" id="quantidade-1">0</span>
                            <button class="btn-quantidade" onclick="aumentarQuantidade(1)">+</button>
                        </div>
                    </div>

                    <!-- X-Bacon -->
                    <div class="produto" data-id="2" data-nome="X-Bacon" data-preco="22.00">
                        <div class="produto-info">
                            <img src="assets/Xbacon.jpg" alt="X-Bacon" class="produto-imagem">
                            <div class="produto-detalhes">
                                <span class="produto-nome">X-Bacon</span>
                                <span class="produto-desc">Hambúrguer, queijo e bacon</span>
                            </div>
                        </div>
                        <span class="produto-preco">R$ 22,00</span>
                        <div class="produto-controles">
                            <button class="btn-quantidade" onclick="diminuirQuantidade(2)">-</button>
                            <span class="quantidade" id="quantidade-2">0</span>
                            <button class="btn-quantidade" onclick="aumentarQuantidade(2)">+</button>
                        </div>
                    </div>

                    <!-- X-Egg -->
                    <div class="produto" data-id="3" data-nome="X-Egg" data-preco="20.00">
                        <div class="produto-info">
                            <img src="assets/Xegg.jpg" alt="X-Egg" class="produto-imagem">
                            <div class="produto-detalhes">
                                <span class="produto-nome">X-Egg</span>
                                <span class="produto-desc">Hambúrguer, queijo e ovo</span>
                            </div>
                        </div>
                        <span class="produto-preco">R$ 20,00</span>
                        <div class="produto-controles">
                            <button class="btn-quantidade" onclick="diminuirQuantidade(3)">-</button>
                            <span class="quantidade" id="quantidade-3">0</span>
                            <button class="btn-quantidade" onclick="aumentarQuantidade(3)">+</button>
                        </div>
                    </div>

                    <!-- X-Tudo -->
                    <div class="produto" data-id="4" data-nome="X-Tudo" data-preco="27.00">
                        <div class="produto-info">
                            <img src="assets/Xtudo.jpg" alt="X-Tudo" class="produto-imagem">
                            <div class="produto-detalhes">
                                <span class="produto-nome">X-Tudo</span>
                                <span class="produto-desc">Hambúrguer, queijo, bacon, frango, calabresa, salsicha, tomate, alface, milho e ervilha</span>
                            </div>
                        </div>
                        <span class="produto-preco">R$ 27,00</span>
                        <div class="produto-controles">
                            <button class="btn-quantidade" onclick="diminuirQuantidade(4)">-</button>
                            <span class="quantidade" id="quantidade-4">0</span>
                            <button class="btn-quantidade" onclick="aumentarQuantidade(4)">+</button>
                        </div>
                    </div>

                    <!-- X-Super -->
                    <div class="produto" data-id="5" data-nome="X-Super" data-preco="24.00">
                        <div class="produto-info">
                            <img src="assets/Xsuper.jpg" alt="X-Super" class="produto-imagem">
                            <div class="produto-detalhes">
                                <span class="produto-nome">X-Super</span>
                                <span class="produto-desc">Hambúrguer, queijo, salsicha, alface, milho e ervilha</span>
                            </div>
                        </div>
                        <span class="produto-preco">R$ 24,00</span>
                        <div class="produto-controles">
                            <button class="btn-quantidade" onclick="diminuirQuantidade(5)">-</button>
                            <span class="quantidade" id="quantidade-5">0</span>
                            <button class="btn-quantidade" onclick="aumentarQuantidade(5)">+</button>
                        </div>
                    </div>
                </div>

                <!-- CATEGORIA: BEBIDAS -->
                <div class="categoria">
                    <h2>Bebidas</h2>
                    
                    <!-- Coca-Cola -->
                    <div class="produto" data-id="6" data-nome="Coca-Cola" data-preco="6.00">
                        <div class="produto-info">
                            <img src="assets/cocacola.webp" alt="Coca-Cola" class="produto-imagem">
                            <div class="produto-detalhes">
                                <span class="produto-nome">Coca-Cola</span>
                                <span class="produto-desc">Lata 350ml</span>
                            </div>
                        </div>
                        <span class="produto-preco">R$ 6,00</span>
                        <div class="produto-controles">
                            <button class="btn-quantidade" onclick="diminuirQuantidade(6)">-</button>
                            <span class="quantidade" id="quantidade-6">0</span>
                            <button class="btn-quantidade" onclick="aumentarQuantidade(6)">+</button>
                        </div>
                    </div>

                    <!-- Água -->
                    <div class="produto" data-id="7" data-nome="Água" data-preco="3.50">
                        <div class="produto-info">
                            <img src="assets/agua.png" alt="Água" class="produto-imagem">
                            <div class="produto-detalhes">
                                <span class="produto-nome">Água</span>
                                <span class="produto-desc">Garrafa 500ml</span>
                            </div>
                        </div>
                        <span class="produto-preco">R$ 3,50</span>
                        <div class="produto-controles">
                            <button class="btn-quantidade" onclick="diminuirQuantidade(7)">-</button>
                            <span class="quantidade" id="quantidade-7">0</span>
                            <button class="btn-quantidade" onclick="aumentarQuantidade(7)">+</button>
                        </div>
                    </div>

                    <!-- Suco de Laranja -->
                    <div class="produto" data-id="8" data-nome="Suco de Laranja" data-preco="12.00">
                        <div class="produto-info">
                            <img src="assets/suco_laranja.webp" alt="Suco de Laranja" class="produto-imagem">
                            <div class="produto-detalhes">
                                <span class="produto-nome">Suco de Laranja</span>
                                <span class="produto-desc">Copo 600ml</span>
                            </div>
                        </div>
                        <span class="produto-preco">R$ 12,00</span>
                        <div class="produto-controles">
                            <button class="btn-quantidade" onclick="diminuirQuantidade(8)">-</button>
                            <span class="quantidade" id="quantidade-8">0</span>
                            <button class="btn-quantidade" onclick="aumentarQuantidade(8)">+</button>
                        </div>
                    </div>

                    <!-- Coca-Cola zero -->
                    <div class="produto" data-id="9" data-nome="Coca-Cola zero" data-preco="6.00">
                        <div class="produto-info">
                            <img src="assets/cocazero.png" alt="Coca-Cola zero" class="produto-imagem">
                            <div class="produto-detalhes">
                                <span class="produto-nome">Coca-Cola zero</span>
                                <span class="produto-desc">Lata 350ml</span>
                            </div>
                        </div>
                        <span class="produto-preco">R$ 6,00</span>
                        <div class="produto-controles">
                            <button class="btn-quantidade" onclick="diminuirQuantidade(9)">-</button>
                            <span class="quantidade" id="quantidade-9">0</span>
                            <button class="btn-quantidade" onclick="aumentarQuantidade(9)">+</button>
                        </div>
                    </div>

                    <!-- Guaraná -->
                    <div class="produto" data-id="10" data-nome="Guaraná" data-preco="5.00">
                        <div class="produto-info">
                            <img src="assets/guarana.webp" alt="Guaraná" class="produto-imagem">
                            <div class="produto-detalhes">
                                <span class="produto-nome">Guaraná</span>
                                <span class="produto-desc">Lata 350ml</span>
                            </div>
                        </div>
                        <span class="produto-preco">R$ 5,00</span>
                        <div class="produto-controles">
                            <button class="btn-quantidade" onclick="diminuirQuantidade(10)">-</button>
                            <span class="quantidade" id="quantidade-10">0</span>
                            <button class="btn-quantidade" onclick="aumentarQuantidade(10)">+</button>
                        </div>
                    </div>
                </div>

                <!-- CATEGORIA: ACOMPANHAMENTOS -->
                <div class="categoria">
                    <h2>Acompanhamentos</h2>
                    
                    <!-- Batata frita pequena -->
                    <div class="produto" data-id="11" data-nome="Batata frita pequena" data-preco="20.00">
                        <div class="produto-info">
                            <img src="assets/batataM.jpg" alt="Batata frita pequena" class="produto-imagem">
                            <div class="produto-detalhes">
                                <span class="produto-nome">Batata frita pequena</span>
                                <span class="produto-desc">Cheddar + bacon + batata + molho rosa e verde</span>
                            </div>
                        </div>
                        <span class="produto-preco">R$ 20,00</span>
                        <div class="produto-controles">
                            <button class="btn-quantidade" onclick="diminuirQuantidade(11)">-</button>
                            <span class="quantidade" id="quantidade-11">0</span>
                            <button class="btn-quantidade" onclick="aumentarQuantidade(11)">+</button>
                        </div>
                    </div>

                    <!-- Batata frita grande -->
                    <div class="produto" data-id="12" data-nome="Batata frita grande" data-preco="40.00">
                        <div class="produto-info">
                            <img src="assets/batataG.jpg" alt="Batata frita grande" class="produto-imagem">
                            <div class="produto-detalhes">
                                <span class="produto-nome">Batata frita grande</span>
                                <span class="produto-desc">Cheddar + bacon + batata + molho rosa e verde</span>
                            </div>
                        </div>
                        <span class="produto-preco">R$ 40,00</span>
                        <div class="produto-controles">
                            <button class="btn-quantidade" onclick="diminuirQuantidade(12)">-</button>
                            <span class="quantidade" id="quantidade-12">0</span>
                            <button class="btn-quantidade" onclick="aumentarQuantidade(12)">+</button>
                        </div>
                    </div>

                    <!-- Polenta frita -->
                    <div class="produto" data-id="13" data-nome="Polenta frita" data-preco="15.00">
                        <div class="produto-info">
                            <img src="assets/polenta-frita-rapida.jpg" alt="Polenta frita" class="produto-imagem">
                            <div class="produto-detalhes">
                                <span class="produto-nome">Polenta frita</span>
                                <span class="produto-desc">Queijo + Mandioca frita + Aneis de cebola frita</span>
                            </div>
                        </div>
                        <span class="produto-preco">R$ 15,00</span>
                        <div class="produto-controles">
                            <button class="btn-quantidade" onclick="diminuirQuantidade(13)">-</button>
                            <span class="quantidade" id="quantidade-13">0</span>
                            <button class="btn-quantidade" onclick="aumentarQuantidade(13)">+</button>
                        </div>
                    </div>

                    <!-- Frios -->
                    <div class="produto" data-id="14" data-nome="Frios" data-preco="10.00">
                        <div class="produto-info">
                            <img src="assets/frios.jpg" alt="Frios" class="produto-imagem">
                            <div class="produto-detalhes">
                                <span class="produto-nome">Frios</span>
                                <span class="produto-desc">Queijo + Pepino + Ovo de Codorna + Salaminho + Azeitona</span>
                            </div>
                        </div>
                        <span class="produto-preco">R$ 10,00</span>
                        <div class="produto-controles">
                            <button class="btn-quantidade" onclick="diminuirQuantidade(14)">-</button>
                            <span class="quantidade" id="quantidade-14">0</span>
                            <button class="btn-quantidade" onclick="aumentarQuantidade(14)">+</button>
                        </div>
                    </div>
                </div>
            </div>
      
            <div class="resumo-pedido">
                <h2>Resumo do Pedido</h2>
                <div class="itens-pedido" id="itens-pedido">
                    <div class="vazio">Seu carrinho está vazio</div>
                </div>
                <div class="total-pedido">
                    <span>Total:</span>
                    <span id="total-pedido">R$ 0,00</span>
                </div>
                <button class="btn-comprar" onclick="finalizarPedido()">Finalizar Pedido</button>
            </div>
        </div>
    </div>

    <!-- MODAIS (MANTIDOS IGUAIS) -->
    <div id="modal-pagamento" class="modal">
        <div class="modal-content">
            <h2>Forma de Pagamento</h2>
            <p>Como você prefere pagar?</p>
            
            <div class="metodos-pagamento">
                <button class="btn-metodo" onclick="selecionarPagamento('cartao')">Cartão</button>
                <button class="btn-metodo" onclick="selecionarPagamento('pix')">PIX</button>
                <button class="btn-metodo" onclick="selecionarPagamento('dinheiro')">Dinheiro</button>
            </div>
            
            <button id="btn-confirmar-pagamento" class="btn-confirmar" onclick="confirmarPagamento()" disabled>Confirmar Pagamento</button>
            <button class="btn-fechar" onclick="fecharModal('modal-pagamento')">Voltar ao Carrinho</button>
        </div>
    </div>

    <div id="modal-processando" class="modal">
        <div class="modal-content">
            <div class="processo-loading">
                <div class="loader"></div>
                <h3>Processando pagamento...</h3>
                <p>Aguarde um momento</p>
            </div>
        </div>
    </div>

    <div id="modal-confirmacao" class="modal">
        <div class="modal-content">
            <h2>Pedido Confirmado!</h2>
            
            <div class="confirmacao-item">
                <span>Número do Pedido:</span>
                <strong id="numero-pedido">-</strong>
            </div>
            
            <div class="confirmacao-item">
                <span>Total:</span>
                <strong id="resumo-total">R$ 0,00</strong>
            </div>
            
            <div class="confirmacao-item">
                <span>Pagamento:</span>
                <strong id="resumo-metodo">-</strong>
            </div>
            
            <div class="confirmacao-item">
                <span>Previsão de Entrega:</span>
                <strong>30-40 minutos</strong>
            </div>
            
            <button class="btn-confirmar" onclick="novoPedido()">Fazer Novo Pedido</button>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>