<?php
include 'conexao.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histórico de Pedidos - Hamburgueria Videira</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .filtros {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .filtro-group {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 15px;
        }
        
        .filtro-item {
            flex: 1;
            min-width: 200px;
        }
        
        .filtro-item label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: var(--gray-800);
        }
        
        .filtro-item input, .filtro-item select {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--gray-200);
            border-radius: 5px;
        }
        
        .btn-filtrar {
            background: var(--primary);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }
        
        .estatisticas {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .card-estatistica {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .card-estatistica h3 {
            color: var(--gray-600);
            font-size: 0.9rem;
            margin-bottom: 10px;
        }
        
        .card-estatistica .valor {
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--primary);
        }
        
        .tabela-pedidos {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid var(--gray-200);
        }
        
        th {
            background: var(--gray-200);
            font-weight: bold;
            color: var(--gray-800);
        }
        
        tr:hover {
            background: #f8fafc;
        }
        
        .sem-resultados {
            text-align: center;
            padding: 40px;
            color: var(--gray-600);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Histórico de Pedidos</h1>
            <p>Consulte todos os pedidos realizados e visualize estatísticas</p>
            <a href="index.php" style="color: var(--primary); text-decoration: none;">← Voltar para Cardápio</a>
        </div>

        <?php
        // Processar filtros
        $filtro_data = $_GET['data'] ?? '';
        $filtro_produto = $_GET['produto'] ?? '';
        $filtro_valor_min = $_GET['valor_min'] ?? '';
        $filtro_valor_max = $_GET['valor_max'] ?? '';
        
        // Construir query base
        $sql_pedidos = "SELECT p.id, p.datav, pr.nome as produto_nome, p.quantidade, p.valor_total 
                       FROM pedidos p 
                       JOIN produtos pr ON p.id_produto = pr.id 
                       WHERE 1=1";
        
        if ($filtro_data) {
            $sql_pedidos .= " AND p.datav = '" . mysqli_real_escape_string($conexao, $filtro_data) . "'";
        }
        if ($filtro_produto) {
            $sql_pedidos .= " AND pr.nome LIKE '%" . mysqli_real_escape_string($conexao, $filtro_produto) . "%'";
        }
        if ($filtro_valor_min) {
            $sql_pedidos .= " AND p.valor_total >= " . floatval($filtro_valor_min);
        }
        if ($filtro_valor_max) {
            $sql_pedidos .= " AND p.valor_total <= " . floatval($filtro_valor_max);
        }
        
        $sql_pedidos .= " ORDER BY p.datav DESC, p.id DESC";
        $resultado_pedidos = mysqli_query($conexao, $sql_pedidos);
        
        // Estatísticas

    $sql_estatisticas = "SELECT 
                    COUNT(*) as total_pedidos,
                    SUM(p.valor_total) as faturamento_total,
                    AVG(p.valor_total) as ticket_medio,
                    (SELECT pr.nome FROM pedidos pd 
                     JOIN produtos pr ON pd.id_produto = pr.id 
                     GROUP BY pd.id_produto, pr.nome  -- ADICIONAR pr.nome no GROUP BY
                     ORDER BY SUM(pd.quantidade) DESC 
                     LIMIT 1) as produto_mais_vendido
                    FROM pedidos p";
        
        $result_estatisticas = mysqli_query($conexao, $sql_estatisticas);
        $estatisticas = mysqli_fetch_assoc($result_estatisticas);
        ?>

        <!-- Filtros -->
        <div class="filtros">
            <form method="GET" action="historico.php">
                <div class="filtro-group">
                    <div class="filtro-item">
                        <label for="data">Data:</label>
                        <input type="date" id="data" name="data" value="<?= htmlspecialchars($filtro_data) ?>">
                    </div>
                    <div class="filtro-item">
                        <label for="produto">Produto:</label>
                        <input type="text" id="produto" name="produto" value="<?= htmlspecialchars($filtro_produto) ?>" placeholder="Nome do produto">
                    </div>
                    <div class="filtro-item">
                        <label for="valor_min">Valor Mínimo:</label>
                        <input type="number" id="valor_min" name="valor_min" step="0.01" value="<?= htmlspecialchars($filtro_valor_min) ?>" placeholder="R$ 0,00">
                    </div>
                    <div class="filtro-item">
                        <label for="valor_max">Valor Máximo:</label>
                        <input type="number" id="valor_max" name="valor_max" step="0.01" value="<?= htmlspecialchars($filtro_valor_max) ?>" placeholder="R$ 100,00">
                    </div>
                </div>
                <button type="submit" class="btn-filtrar">Aplicar Filtros</button>
                <a href="historico.php" style="margin-left: 10px; color: var(--gray-600);">Limpar</a>
            </form>
        </div>

        <!-- Estatísticas -->
        <div class="estatisticas">
            <div class="card-estatistica">
                <h3>Total de Pedidos</h3>
                <div class="valor"><?= $estatisticas['total_pedidos'] ?? 0 ?></div>
            </div>
            <div class="card-estatistica">
                <h3>Faturamento Total</h3>
                <div class="valor">R$ <?= number_format($estatisticas['faturamento_total'] ?? 0, 2, ',', '.') ?></div>
            </div>
            <div class="card-estatistica">
                <h3>Ticket Médio</h3>
                <div class="valor">R$ <?= number_format($estatisticas['ticket_medio'] ?? 0, 2, ',', '.') ?></div>
            </div>
            <div class="card-estatistica">
                <h3>Produto Mais Vendido</h3>
                <div class="valor"><?= $estatisticas['produto_mais_vendido'] ?? 'N/A' ?></div>
            </div>
        </div>

        <!-- Tabela de Pedidos -->
        <div class="tabela-pedidos">
            <?php if (mysqli_num_rows($resultado_pedidos) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID Pedido</th>
                            <th>Data</th>
                            <th>Produto</th>
                            <th>Quantidade</th>
                            <th>Valor Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($pedido = mysqli_fetch_assoc($resultado_pedidos)): ?>
                            <tr>
                                <td>#<?= $pedido['id'] ?></td>
                                <td><?= date('d/m/Y', strtotime($pedido['datav'])) ?></td>
                                <td><?= htmlspecialchars($pedido['produto_nome']) ?></td>
                                <td><?= $pedido['quantidade'] ?></td>
                                <td>R$ <?= number_format($pedido['valor_total'], 2, ',', '.') ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="sem-resultados">
                    Nenhum pedido encontrado com os filtros aplicados.
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>