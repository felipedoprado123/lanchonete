<?php
include 'conexao.php';

header('Content-Type: application/json');

// RECEBE DADOS DO AJAX
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['itens'])) {
    echo json_encode(['success' => false, 'error' => 'Dados inválidos']);
    exit;
}

try {
    // SALVA CADA ITEM DO PEDIDO
    $pedido_id = null;
    
    foreach ($input['itens'] as $item) {
        $resultado = registrar_pedido(
            $item['id_produto'],
            $item['quantidade'],
            $item['valor_total']
        );
        
        if (!$resultado) {
            throw new Exception('Erro ao salvar item do pedido');
        }
        
        // Pega o ID do último pedido inserido (apenas do primeiro item)
        if ($pedido_id === null) {
            $pedido_id = mysqli_insert_id($conexao);
        }
    }
    
    echo json_encode([
        'success' => true,
        'pedido_id' => $pedido_id
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>