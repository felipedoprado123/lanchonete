// SISTEMA PRINCIPAL
const sistema = {
    pedido: {},
    metodoPagamento: null,
    pedidoNumero: null
};

// FUNÇÕES DE QUANTIDADE
function aumentarQuantidade(id) {
    const quantidadeElement = document.getElementById(`quantidade-${id}`);
    let quantidade = parseInt(quantidadeElement.textContent) || 0;
    quantidade++;
    quantidadeElement.textContent = quantidade;
    atualizarPedido(id, quantidade);
}

function diminuirQuantidade(id) {
    const quantidadeElement = document.getElementById(`quantidade-${id}`);
    let quantidade = parseInt(quantidadeElement.textContent) || 0;
    if (quantidade > 0) {
        quantidade--;
        quantidadeElement.textContent = quantidade;
        atualizarPedido(id, quantidade);
    }
}

// ATUALIZAR PEDIDO
function atualizarPedido(id, quantidade) {
    const produtoElement = document.querySelector(`[data-id="${id}"]`);
    const nome = produtoElement.dataset.nome;
    const preco = parseFloat(produtoElement.dataset.preco);
    
    if (quantidade === 0) {
        delete sistema.pedido[id];
    } else {
        sistema.pedido[id] = {
            nome: nome,
            preco: preco,
            quantidade: quantidade,
            subtotal: preco * quantidade
        };
    }
    
    atualizarResumoPedido();
}

// ATUALIZAR RESUMO
function atualizarResumoPedido() {
    const itensPedido = document.getElementById('itens-pedido');
    const totalPedido = document.getElementById('total-pedido');
    
    itensPedido.innerHTML = '';
    
    if (Object.keys(sistema.pedido).length === 0) {
        itensPedido.innerHTML = '<div class="vazio">Seu carrinho está vazio</div>';
        totalPedido.textContent = 'R$ 0,00';
        return;
    }
    
    let total = 0;
    
    for (const id in sistema.pedido) {
        const item = sistema.pedido[id];
        total += item.subtotal;
        
        const itemElement = document.createElement('div');
        itemElement.className = 'item-pedido';
        itemElement.innerHTML = `
            <div>
                <strong>${item.quantidade}x</strong> ${item.nome}
            </div>
            <div>R$ ${item.subtotal.toFixed(2).replace('.', ',')}</div>
        `;
        itensPedido.appendChild(itemElement);
    }
    
    totalPedido.textContent = `R$ ${total.toFixed(2).replace('.', ',')}`;
}

// CALCULAR TOTAL
function calcularTotal() {
    let total = 0;
    for (const id in sistema.pedido) {
        total += sistema.pedido[id].subtotal;
    }
    return total;
}

// FINALIZAR PEDIDO
function finalizarPedido() {
    if (Object.keys(sistema.pedido).length === 0) {
        alert('Adicione itens ao pedido antes de finalizar!');
        return;
    }
    
    document.getElementById('modal-pagamento').style.display = 'block';
}

// SELECIONAR PAGAMENTO
function selecionarPagamento(metodo) {
    sistema.metodoPagamento = metodo;
    
    // Remover seleção anterior
    document.querySelectorAll('.btn-metodo').forEach(btn => {
        btn.classList.remove('selecionado');
    });
    
    // Adicionar seleção atual
    event.target.classList.add('selecionado');
    
    // Habilitar botão de confirmar
    document.getElementById('btn-confirmar-pagamento').disabled = false;
}

// FECHAR MODAL
function fecharModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// CONFIRMAR PAGAMENTO (JÁ EXISTENTE - MANTIDO)
function confirmarPagamento() {
    if (!sistema.metodoPagamento) {
        alert('Selecione um método de pagamento');
        return;
    }
    
    document.getElementById('modal-pagamento').style.display = 'none';
    document.getElementById('modal-processando').style.display = 'block';
    
    salvarPedidoNoBanco()
        .then(pedidoId => {
            sistema.pedidoNumero = 'PED' + pedidoId;
            const total = calcularTotal();
            document.getElementById('resumo-total').textContent = `R$ ${total.toFixed(2).replace('.', ',')}`;
            document.getElementById('resumo-metodo').textContent = formatarMetodoPagamento(sistema.metodoPagamento);
            document.getElementById('numero-pedido').textContent = sistema.pedidoNumero;
            
            document.getElementById('modal-processando').style.display = 'none';
            document.getElementById('modal-confirmacao').style.display = 'block';
        })
        .catch(error => {
            console.error('Erro ao salvar pedido:', error);
            alert('Erro ao processar pedido. Tente novamente.');
            document.getElementById('modal-processando').style.display = 'none';
        });
}

// FORMATAR MÉTODO PAGAMENTO
function formatarMetodoPagamento(metodo) {
    const metodos = {
        'cartao': 'Cartão de Crédito',
        'pix': 'PIX',
        'dinheiro': 'Dinheiro'
    };
    return metodos[metodo] || metodo;
}

// SALVAR PEDIDO NO BANCO (JÁ EXISTENTE - MANTIDO)
function salvarPedidoNoBanco() {
    return new Promise((resolve, reject) => {
        const itensPedido = [];
        for (const id in sistema.pedido) {
            itensPedido.push({
                id_produto: id,
                quantidade: sistema.pedido[id].quantidade,
                valor_total: sistema.pedido[id].subtotal
            });
        }
        
        fetch('salvar_pedido.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                itens: itensPedido,
                metodo_pagamento: sistema.metodoPagamento
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                resolve(data.pedido_id);
            } else {
                reject(data.error);
            }
        })
        .catch(error => reject(error));
    });
}

// NOVO PEDIDO
function novoPedido() {
    // Limpar pedido atual
    sistema.pedido = {};
    sistema.metodoPagamento = null;
    sistema.pedidoNumero = null;
    
    // Resetar quantidades na interface
    document.querySelectorAll('.quantidade').forEach(element => {
        element.textContent = '0';
    });
    
    // Atualizar resumo
    atualizarResumoPedido();
    
    // Fechar modal
    document.getElementById('modal-confirmacao').style.display = 'none';
}