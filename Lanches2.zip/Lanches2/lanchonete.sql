CREATE DATABASE lanchonete;
USE lanchonete;

CREATE TABLE produtos (
    id INT NOT NULL AUTO_INCREMENT, 
    nome VARCHAR(45) NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    categoria VARCHAR(45) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE pedidos (
    id INT NOT NULL AUTO_INCREMENT,
    data DATE NOT NULL,  -- CORRIGIDO: datav → data
    id_produto INT NOT NULL,
    quantidade INT NOT NULL, 
    valor_total DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id_produto) REFERENCES produtos(id)
);

INSERT INTO produtos (nome, preco, categoria) VALUES
('X-Salada', 18.50, 'Lanches'),
('X-Bacon', 22.00, 'Lanches'),
('X-Egg', 20.00, 'Lanches'),
('X-Tudo', 27.00, 'Lanches'),
('X-Super', 24.00, 'Lanches'),
('Coca-Cola', 6.00, 'Bebidas'),
('Água', 3.50, 'Bebidas'),
('Suco de Laranja', 12.00, 'Bebidas'),
('Coca-Cola zero', 6.00, 'Bebidas'),
('Guaraná', 5.00, 'Bebidas'),
('Batata frita pequena', 20.00, 'Acompanhamentos'),
('Batata frita grande', 40.00, 'Acompanhamentos'),
('Polenta frita', 15.00, 'Acompanhamentos'),
('Frios', 10.00, 'Acompanhamentos');