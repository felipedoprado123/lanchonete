<?php
$host = "localhost";    
$usuario = "root";      
$senha = "";            
$banco = "lanchonete";  

// ESTABELECE CONEXÃO COM MYSQL
$conexao = mysqli_connect($host, $usuario, $senha, $banco);

// VERIFICA SE HOUVE ERRO NA CONEXÃO
if (!$conexao) {
    die("Erro na conexão: " . mysqli_connect_error());
}

// FUNÇÃO: BUSCA PRODUTOS DO BANCO
function buscar_produtos($categoria = null) {
    global $conexao;
    
    // CONSTRÓI QUERY SQL DINAMICAMENTE
    $sql = "SELECT * FROM produtos";
    if ($categoria) {
        // FILTRA POR CATEGORIA SE ESPECIFICADA
        $sql .= " WHERE categoria = '" . mysqli_real_escape_string($conexao, $categoria) . "'";
    }
    
    $resultado = mysqli_query($conexao, $sql);
    
    // TRATA ERROS NA CONSULTA
    if (!$resultado) {
        error_log("Erro no banco: " . mysqli_error($conexao));
        return [];
    }
    
    // CONVERTE RESULTADO EM ARRAY ASSOCIATIVO
    $produtos = [];
    while ($produto = mysqli_fetch_assoc($resultado)) {
        $produtos[] = $produto;
    }
    
    return $produtos;
}

// FUNÇÃO: REGISTRA PEDIDO NO BANCO
function registrar_pedido($id_produto, $quantidade, $valor_total) {
    global $conexao;
    
    $data = date('Y-m-d');  // DATA ATUAL NO FORMATO MYSQL
    
    // QUERY PREPARADA PARA SEGURANÇA
    $sql = "INSERT INTO pedidos (datav, id_produto, quantidade, valor_total) 
            VALUES (?, ?, ?, ?)";
    
    $stmt = mysqli_prepare($conexao, $sql);
    if (!$stmt) {
        return false;  // ERRO AO PREPARAR QUERY
    }
    
    // VINCULA PARÂMETROS (PREVINE SQL INJECTION)
    mysqli_stmt_bind_param($stmt, 'siid', $data, $id_produto, $quantidade, $valor_total);
    $executou = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    
    return $executou;  // RETORNA SE FOI BEM-SUCEDIDO
}
?>