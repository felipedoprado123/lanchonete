<?php
// processar_pedido.php
require_once 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['produto'])) {
    $pedidos = $_POST['produto'];
    
    foreach ($pedidos as $id_produto => $quantidade) {
        $quantidade = intval($quantidade);
        
        if ($quantidade > 0) {
            // Buscar preço do produto
            $sql = "SELECT preco FROM produtos WHERE id = " . intval($id_produto);
            $resultado = mysqli_query($conexao, $sql);
            
            if ($resultado && $produto = mysqli_fetch_assoc($resultado)) {
                $valor_total = $quantidade * $produto['preco'];
                
                // Registrar pedido
                if (registrar_pedido($id_produto, $quantidade, $valor_total)) {
                    echo "Pedido do produto ID $id_produto registrado com sucesso!<br>";
                } else {
                    echo "Erro ao registrar pedido do produto ID $id_produto.<br>";
                }
            }
        }
    }
    
    echo "<a href='index.php'>Voltar ao cardápio</a>";
} else {
?>
    header('Location: index.php');
    exit;
}